/********************************************************************************
* main.c: Demonstration av timerkretsar Timer 0 - Timer 2 f�r toggling av
*         lysdioder samt debouncing.
*
*         Timer 1 samt Timer 2 anv�nds f�r att toggla tv� lysdioder anslutna 
*         till pin 8 - 9 (PORTB0 - PORTB1) med blinkhastigheten 100 ms 
*         respektive 50 ms. Detta sker n�r timergenererat avbrott �r aktiverat
*         p� given timer, annars h�lls motsvarande lysdiod sl�ckt.
*
*         F�r att toggla aktivering av avbrott p� timerkretsarna anv�nds 
*         tv� tryckknappar anslutna till pin 12 - 13 (PORTB4 - PORTB5),
*         som PCI-avbrott har aktiverats p�. Vid nedtryckning av tryckknappen
*         ansluten till pin 12 (PORTB4) togglas avbrott p� Timer 1, medan 
*         nedtryckning av tryckknappen ansluten till pin 13 (PORTB5) medf�r
*         toggling av avbrott p� Timer 2.
*
*         F�r att undvika multipla avbrott p� grund av kontaktstudsar vid
*         nedtryckning av tryckknapparna inaktiveras PCI-avbrott p� I/O-port B
*         i 300 ms efter att avbrott sker. R�kningen genomf�rs av timerkrets
*         Timer 0, som avbrott aktiveras d� aktiveras p�. Efter att 300 ms har
*         passerat �terst�lls PCI-avbrott p� I/O-port B och timergenererat 
*         avbrott p� Timer 0 inaktiveras inf�r n�sta nedtryckning av godtycklig
*         tryckknapp.
********************************************************************************/
#include "header.h"

/********************************************************************************
* main: Initierar mikrodatorns I/O-portar och timerkretsar vid start. Sedan
*       h�lls programmet ig�ng s� l�nge matningssp�nning tillf�rs. Resten av
*       programmet �r avbrottsgenererat.
********************************************************************************/
int main(void)
{
   setup();

   while (1)
   {

   }

   return 0;
}

