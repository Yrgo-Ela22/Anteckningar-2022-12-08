# Anteckningar 2022-12-08
Demonstration av timerkretsar Timer 0 - Timer 2 för toggling av lysdioder samt debouncing.

Timer 1 samt Timer 2 används för att toggla två lysdioder anslutna till pin 8 - 9 (PORTB0 - PORTB1) 
med blinkhastigheten 100 ms respektive 50 ms. Detta sker när timergenererat avbrott är aktiverat
på given timer, annars hålls motsvarande lysdiod släckt.

För att toggla aktivering av avbrott på timerkretsarna används två tryckknappar anslutna till 
pin 12 - 13 (PORTB4 - PORTB5), som PCI-avbrott har aktiverats på. Vid nedtryckning av tryckknappen
ansluten till pin 12 (PORTB4) togglas avbrott på Timer 1, medan nedtryckning av tryckknappen ansluten 
till pin 13 (PORTB5) medför toggling av avbrott på Timer 2.

För att undvika multipla avbrott på grund av kontaktstudsar vid nedtryckning av tryckknapparna inaktiveras 
PCI-avbrott på I/O-port B i 300 ms efter att avbrott sker. Räkningen genomförs av timerkrets Timer 0, 
som avbrott aktiveras då aktiveras på. Efter att 300 ms har passerat återställs PCI-avbrott på I/O-port B 
och timergenererat  avbrott på Timer 0 inaktiveras inför nästa nedtryckning av godtyckligtryckknapp.