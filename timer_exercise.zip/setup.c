/********************************************************************************
* setup.c: Inneh�ller initieringsrutiner.
********************************************************************************/
#include "header.h"

/* Definition av globala variabler: */
volatile bool timer1_enabled = false;
volatile bool timer2_enabled = false;

/* Statiska funktioner: */
static inline void init_ports(void);
static inline void init_interrupts(void);
static inline void init_timers(void);

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt timerkretsar Timer 0 - Timer 2.
********************************************************************************/
void setup(void)
{
   init_ports();
   init_interrupts();
   init_timers();
   return;
}

/********************************************************************************
* init_ports: S�tter lysdiodernas pinnar till utportar genom att ettst�lla
*             motsvarande bitar i datariktningsregister DDRB. Interna pullup-
*             resistorer p� tryckknapparnas pinnar aktiveras via ettst�llning
*             av motsvarande bitar i dataregister PORTB.
********************************************************************************/
static inline void init_ports(void)
{
   DDRB = (1 << LED1) | (1 << LED2);
   PORTB = (1 << BUTTON1) | (1 << BUTTON2);
   return;
}

/********************************************************************************
* init_interrupts: Aktiverar PCI-avbrott p� tryckknapparnas pinnar s� att
*                  avbrott sker vid uppsl�ppning och nedtryckning av dem.
********************************************************************************/
static inline void init_interrupts(void)
{
   asm("SEI");
   PCICR = (1 << PCIE0);
   PCMSK0 = (1 << BUTTON1) | (1 << BUTTON2);
   return;
}

/********************************************************************************
* init_timers: Initierar timerkretsar Timer 0 - Timer 2 s� att timergenererat
*              avbrott sker var 0.128 ms per timerkrets. Samtliga timerkretsar
*              �r inaktiverade vid start.
********************************************************************************/
static inline void init_timers(void)
{
   asm("SEI");
   TCCR0B = (1 << CS01);
   TCCR1B = (1 << WGM12) | (1 << CS11);
   OCR1A = 256;
   TCCR2B = (1 << CS11);
   return;
}