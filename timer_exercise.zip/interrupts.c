/********************************************************************************
* interrupts.c: Inneh�ller avbrottsrutiner.
********************************************************************************/
#include "header.h"

/********************************************************************************
* ISR (PCINT0_vect): Avbrottsrutin som �ger rum vid nedtryckning/uppsl�ppning
*                    av n�gon av tryckknapparna. Beroende p� vilken tryckknapp
*                    som trycks ned s� togglas antingen Timer 1 eller Timer 2.
*                    Vid uppsl�ppning av en tryckknapp g�rs ingenting.
*
*                    Oavsett vad som orsakade avbrottet inaktiveras PCI-avbrott
*                    p� I/O-port B i 300 millisekunder via timer 0 f�r att
*                    undvika multipla avbrott orsakade av kontaktstudsar.
********************************************************************************/
ISR (PCINT0_vect)
{
   PCICR &= ~(1 << PCIE0);
   TIMSK0 = (1 << TOIE0);

   if (BUTTON1_IS_PRESSED)
   {
     timer_toggle(&timer1_enabled, LED1, &TIMSK1, OCIE1A);
   }
   else if (BUTTON2_IS_PRESSED)
   {
      timer_toggle(&timer2_enabled, LED2, &TIMSK2, TOIE2);
   }

   return;
}

/********************************************************************************
* ISR (TIMER0_OVF_vect): Avbrottsrutin som �ger rum vid overflow av Timer 0,
*                        dvs. uppr�kning till 256, vilket sker var 0.128:e
*                        millisekund n�r timern �r aktiverad.
*
*                        Timern r�knas upp via uppr�kning av varje passerat
*                        avbrott. N�r timern l�per ut (n�r ber�knat antal
*                        avbrott f�r specificerad tid har r�knats upp) s�
*                        �teraktiveras PCI-avbrott p� I/O-port B (som har
*                        st�ngts av i 300 millisekunder f�r att undvika
*                        multipla avbrott orsakat av kontaktstudsar), f�ljt
*                        av att timern st�ngs av.
********************************************************************************/
ISR (TIMER0_OVF_vect)
{
   static uint16_t counter = 0;

   if (++counter >= timer_get_max_count(300))
   {
      PCICR |= (1 << PCIE0);
      TIMSK0 = 0x00;
      counter = 0;
   }

   return;
}

/********************************************************************************
* ISR (TIMER1_COMPA_vect): Avbrottsrutin som �ger rum vid uppr�kning till 256 av
*                          Timer 1 i CTC Mode, vilket sker var 0.128:e
*                          millisekund n�r timern �r aktiverad.
*
*                          Timern r�knas upp via uppr�kning av varje passerat
*                          avbrott. N�r timern l�per ut (var 100:e millisekund
*                          n�r timern �r aktiverad) togglas lysdiod 1.
********************************************************************************/
ISR (TIMER1_COMPA_vect)
{
   static volatile uint16_t counter = 0;

   if (++counter >= timer_get_max_count(100))
   {
      LED1_TOGGLE;
      counter = 0;
   }

   return;
}

/********************************************************************************
* ISR (TIMER2_OVF_vect): Avbrottsrutin som �ger rum vid overflow av Timer 2,
*                        dvs. uppr�kning till 256, vilket sker var 0.128:e
*                        millisekund n�r timern �r aktiverad.
*
*                        Timern r�knas upp via uppr�kning av varje passerat
*                        avbrott. N�r timern l�per ut (var 50:e millisekund
*                        n�r timern �r aktiverad) togglas lysdiod 2.
********************************************************************************/
ISR (TIMER2_OVF_vect)
{
    static volatile uint16_t counter = 0;

    if (++counter >= timer_get_max_count(50))
    {
       LED2_TOGGLE;
       counter = 0;
    }

    return;
}