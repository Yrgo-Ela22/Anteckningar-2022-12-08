/********************************************************************************
* header.h: Inneh�ller diverse definitioner och deklarationer f�r implementering
*           av det inbyggda systemet.
********************************************************************************/
#ifndef HEADER_H_
#define HEADER_H_

/* Inkluderingsdirektiv: */
#include <avr/io.h>        /* Inneh�ller information om I/O-register s�som PORTB. */
#include <avr/interrupt.h> /* Inneh�ller information om avbrottsvektorer s�som TIMER0_OVF_vect. */
#include <stdbool.h>       /* Inneh�ller deklaration av datatypen bool. */

#define LED1 PORTB0    /* Lysdiod 1 ansluten till pin 8 (PORTB0). */
#define LED2 PORTB1    /* Lysdiod 2 ansluten till pin 9 (PORTB1). */
#define BUTTON1 PORTB4 /* Tryckknapp 1 ansluten till pin 12 (PORTB4). */
#define BUTTON2 PORTB5 /* Tryckknapp 2 ansluten till pin 13 (PORTB5). */

#define LED1_TOGGLE PINB = (1 << LED1) /* Togglar lysdiod 1. */
#define LED2_TOGGLE PINB = (1 << LED2) /* Togglar lysdiod 2. */

#define BUTTON1_IS_PRESSED (PINB & (1 << BUTTON1)) /* Indikerar nedtryckning av tryckknapp 1. */
#define BUTTON2_IS_PRESSED (PINB & (1 << BUTTON2)) /* Indikerar nedtryckning av tryckknapp 2. */

/* Deklaration av globala variabler: */
extern volatile bool timer1_enabled; /* Indikerar ifall Timer 1 �r aktiverad. */
extern volatile bool timer2_enabled; /* Indikerar ifall Timer 2 �r aktiverad. */

/********************************************************************************
* setup: Initierar mikrodatorns I/O-portar samt timerkretsar Timer 0 - Timer 2.
********************************************************************************/
void setup(void);

/********************************************************************************
* timer_get_max_count: Returnerar antalet timergenererat avbrott som kr�vs
*                      f�r att en given timer ska l�pa ut after angiven tid 
*                      i millisekunder. Ber�kning genomf�rd under f�ruts�ttning 
*                      att tiden mellan varje timergenererat avbrott �r
*                      satt till 0.128 millisekunder.
*
*                      - time_ms: F�rfluten tid innan timern ska l�pa ut i ms.
********************************************************************************/
static inline uint32_t timer_get_max_count(const double time_ms)
{
   return (uint32_t)(time_ms / 0.128 + 0.5);
}

/********************************************************************************
* timer_toggle: Togglar aktivering av en given timer via toggling av refererad
*               enable-variable. Om denna variabel togglas till true aktiveras
*               timern i fr�ga och motsvarande lysdiod den kontrollerar t�nds.
*               Annars inaktiveras timern i fr�ga och lysdioden sl�cks.
*
*               - timer_enabled: Pekare till enable-variabel som indikerar
*                                timerns befintliga tillst�nd.
*               - pin          : Pin-nummer till styrd lysdiod p� I/O-port B.
*               - timsk        : Pekare till maskregister f�r aktivering
*                                och inaktivering av timergenererat avbrott.
*               - timsk_bit    : Bit i refererat maskregister som ska ettst�llas
*                                vid eventuell aktivering.
********************************************************************************/
static inline void timer_toggle(volatile bool* timer_enabled,
                                const uint8_t pin,
                                volatile uint8_t* timsk,
                                const uint8_t timsk_bit)
{
   *timer_enabled = !(*timer_enabled);

   if (*timer_enabled)
   {
      PORTB |= (1 << pin);
      *timsk |= (1 << timsk_bit);
   }
   else
   {
      PORTB &= ~(1 << pin);
      *timsk = 0;
   }

   return;
}

#endif /* HEADER_H_ */